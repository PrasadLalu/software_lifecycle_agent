class Constants:
    INPUT_PLACEHOLDER = (
        "I want to develop a user management system with two user types: "
        "Admin and User. Admins will have the ability to create, list, "
        "update, and delete users, while Users will only be able to retrieve "
        "their own details using their user ID."
    )
