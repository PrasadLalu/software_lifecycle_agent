
from src.state.agent_state import LifeCycleState
# from src.tool import evaluate_user_stories

def get_user_requirement(state: LifeCycleState):
    pass