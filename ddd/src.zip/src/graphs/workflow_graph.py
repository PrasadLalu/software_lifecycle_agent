from langgraph.graph import StateGraph, START, END
from src.state.agent_state import LifeCycleState


def build_workflow():
    """Build the workflow graph."""
    pass
